#include <stdio.h>

double C_Sqr (double x)
{
	return x*x;
}

void C_Hello ()
{
	printf("C: Hello.\n");
}